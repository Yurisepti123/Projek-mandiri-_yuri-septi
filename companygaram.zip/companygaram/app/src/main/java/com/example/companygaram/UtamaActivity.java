package com.example.companygaram;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

public class UtamaActivity extends AppCompatActivity {
    String [] judul;
    String [] ket;
    TypedArray gambar;
    String user;
    ImageButton profil,sejarah,vm;
    TextView tuser;
    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_utama);

        profil = findViewById(R.id.btnprofil);
        sejarah = findViewById(R.id.btnsejarah);
        vm = findViewById(R.id.btnvm);

        lv = findViewById(R.id.lvData);
        tuser = findViewById(R.id.eUser);
        user = getIntent().getExtras().getString("user");
        tuser.setText("Selamat Datang,"+user);
        judul = getResources().getStringArray(R.array.array_judul);
        ket = getResources().getStringArray(R.array.array_ket);
        gambar = getResources().obtainTypedArray(R.array.array_logo);
        lvAdapter adapter = new lvAdapter(this,judul,ket,gambar);
        lv.setAdapter(adapter);

        profil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(UtamaActivity.this,profilActivity.class);
                startActivity(p);
            }
        });
        sejarah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(UtamaActivity.this,sejarahActivity.class);
                startActivity(p);
            }
        });
        vm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(UtamaActivity.this,VMActivity.class);
                startActivity(p);
            }
        });
    }
}